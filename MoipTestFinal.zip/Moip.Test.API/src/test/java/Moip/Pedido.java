package Moip;

public class Pedido {

	private String ownId;
	private String amountCurrency;
	private String amountSubShipping;
	private String amountSubaddition;
	private String amountSubdiscount;
	private String itemsProduct;
	private String itemsQuantity;
	private String itemsDetail;
	private String itemsPrice;
	private String custOwnId;
	private String custFullname;
	private String custEmail;
	private String custBirthDate;
	private String taxDocumentType;
	private String taxDocumentNumber;
	private String phoneCountryCode;
	private String phoneAreaCode;
	private String phoneNumber;
	private String shippingAddressCity;
	private String shippingAddressComplement;
	private String shippingAddressDistrict;
	private String shippingAddressStreet;
	private String shippingAddressNumber;
	private String shippingAddressZipCode;
	private String shippingAddressState;
	private String shippingAddressCountry;

	public String getOwnId() {
		return ownId;
	}
	public void setOwnId(String ownId) {
		this.ownId = ownId;
	}
	public String getAmountCurrency() {
		return amountCurrency;
	}
	public void setAmountCurrency(String amountCurrency) {
		this.amountCurrency = amountCurrency;
	}
	public String getAmountSubShipping() {
		return amountSubShipping;
	}
	public void setAmountSubShipping(String amountSubShipping) {
		this.amountSubShipping = amountSubShipping;
	}
	public String getAmountSubaddition() {
		return amountSubaddition;
	}
	public void setAmountSubaddition(String amountSubaddition) {
		this.amountSubaddition = amountSubaddition;
	}
	public String getAmountSubdiscount() {
		return amountSubdiscount;
	}
	public void setAmountSubdiscount(String amountSubdiscount) {
		this.amountSubdiscount = amountSubdiscount;
	}
	public String getItemsProduct() {
		return itemsProduct;
	}
	public void setItemsProduct(String itemsProduct) {
		this.itemsProduct = itemsProduct;
	}
	public String getItemsQuantity() {
		return itemsQuantity;
	}
	public void setItemsQuantity(String itemsQuantity) {
		this.itemsQuantity = itemsQuantity;
	}
	public String getItemsDetail() {
		return itemsDetail;
	}
	public void setItemsDetail(String itemsDetail) {
		this.itemsDetail = itemsDetail;
	}
	public String getItemsPrice() {
		return itemsPrice;
	}
	public void setItemsPrice(String itemsPrice) {
		this.itemsPrice = itemsPrice;
	}
	public String getCustOwnId() {
		return custOwnId;
	}
	public void setCustOwnId(String custOwnId) {
		this.custOwnId = custOwnId;
	}
	public String getCustFullname() {
		return custFullname;
	}
	public void setCustFullname(String custFullname) {
		this.custFullname = custFullname;
	}
	public String getCustEmail() {
		return custEmail;
	}
	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}
	public String getCustBirthDate() {
		return custBirthDate;
	}
	public void setCustBirthDate(String custBirthDate) {
		this.custBirthDate = custBirthDate;
	}
	public String getTaxDocumentType() {
		return taxDocumentType;
	}
	public void setTaxDocumentType(String taxDocumentType) {
		this.taxDocumentType = taxDocumentType;
	}
	public String getTaxDocumentNumber() {
		return taxDocumentNumber;
	}
	public void setTaxDocumentNumber(String taxDocumentNumber) {
		this.taxDocumentNumber = taxDocumentNumber;
	}
	public String getPhoneCountryCode() {
		return phoneCountryCode;
	}
	public void setPhoneCountryCode(String phoneCountryCode) {
		this.phoneCountryCode = phoneCountryCode;
	}
	public String getPhoneAreaCode() {
		return phoneAreaCode;
	}
	public void setPhoneAreaCode(String phoneAreaCode) {
		this.phoneAreaCode = phoneAreaCode;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getShippingAddressCity() {
		return shippingAddressCity;
	}
	public void setShippingAddressCity(String shippingAddressCity) {
		this.shippingAddressCity = shippingAddressCity;
	}
	public String getShippingAddressComplement() {
		return shippingAddressComplement;
	}
	public void setShippingAddressComplement(String shippingAddressComplement) {
		this.shippingAddressComplement = shippingAddressComplement;
	}
	public String getShippingAddressDistrict() {
		return shippingAddressDistrict;
	}
	public void setShippingAddressDistrict(String shippingAddressDistrict) {
		this.shippingAddressDistrict = shippingAddressDistrict;
	}
	public String getShippingAddressStreet() {
		return shippingAddressStreet;
	}
	public void setShippingAddressStreet(String shippingAddressStreet) {
		this.shippingAddressStreet = shippingAddressStreet;
	}
	public String getShippingAddressNumber() {
		return shippingAddressNumber;
	}
	public void setShippingAddressNumber(String shippingAddressNumber) {
		this.shippingAddressNumber = shippingAddressNumber;
	}
	public String getShippingAddressZipCode() {
		return shippingAddressZipCode;
	}
	public void setShippingAddressZipCode(String shippingAddressZipCode) {
		this.shippingAddressZipCode = shippingAddressZipCode;
	}
	public String getShippingAddressState() {
		return shippingAddressState;
	}
	public void setShippingAddressState(String shippingAddressState) {
		this.shippingAddressState = shippingAddressState;
	}
	public String getShippingAddressCountry() {
		return shippingAddressCountry;
	}
	public void setShippingAddressCountry(String shippingAddressCountry) {
		this.shippingAddressCountry = shippingAddressCountry;
	}
}
