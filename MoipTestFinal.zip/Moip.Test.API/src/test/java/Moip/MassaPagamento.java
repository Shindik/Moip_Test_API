package Moip;

public class MassaPagamento {
	

	private int nuCasos = 4; //numero de casos

	Pagamento p1 = new Pagamento();
	Pagamento p2 = new Pagamento();
	Pagamento p3 = new Pagamento();
	Pagamento p4 = new Pagamento();

	private Pagamento pagamentoAux = new Pagamento();
	
	public VetorPagamento pagamentoArray = new VetorPagamento();
	
	String infoPagamento[] = new String [nuCasos];
	
	Acesso acesso = new Acesso();
	
public MassaPagamento () {

	//- Caso 1
	
	p1.setInstallmentCount("1");
	p1.setStatementDescriptor("minhaLoja.com");
	p1.setMethod("CREDIT_CARD");
	p1.setCreditCardHash(acesso.CartaoHash);
	p1.setStore("true");
	p1.setFullname("Cliente Teste 01");
	p1.setBirthdate("1988-12-30");
	p1.setTaxDocumentType("CPF");
	p1.setTaxDocumentNumber("11111111111");
	p1.setPhoneCountry("55");
	p1.setPhoneAreaCode("11");
	p1.setPhoneNumber("66778899");
	
	pagamentoArray.adiciona(p1);

	//- Caso 2

	p2.setInstallmentCount("1");
	p2.setStatementDescriptor("minhaLoja.com");
	p2.setMethod("CREDIT_CARD");
	p2.setCreditCardHash(acesso.CartaoHash);
	p2.setStore("true");
	p2.setFullname("Cliente Teste 02");
	p2.setBirthdate("1988-12-30");
	p2.setTaxDocumentType("CPF");
	p2.setTaxDocumentNumber("22222222222");
	p2.setPhoneCountry("55");
	p2.setPhoneAreaCode("11");
	p2.setPhoneNumber("66778899");
	
	pagamentoArray.adiciona(p2);
	
	//- Caso 3

	p3.setInstallmentCount("1");
	p3.setStatementDescriptor("minhaLoja.com");
	p3.setMethod("CREDIT_CARD");
	p3.setCreditCardHash(acesso.CartaoHash);
	p3.setStore("true");
	p3.setFullname("Cliente Teste 03");
	p3.setBirthdate("1988-12-30");
	p3.setTaxDocumentType("CPF");
	p3.setTaxDocumentNumber("33333333333");
	p3.setPhoneCountry("55");
	p3.setPhoneAreaCode("11");
	p3.setPhoneNumber("66778899");
	
	pagamentoArray.adiciona(p3);

	//- Caso 4

	p4.setInstallmentCount("1");
	p4.setStatementDescriptor("minhaLoja.com");
	p4.setMethod("CREDIT_CARD");
	p4.setCreditCardHash(acesso.CartaoHash);
	p4.setStore("true");
	p4.setFullname("Cliente Teste 04");
	p4.setBirthdate("1988-12-30");
	p4.setTaxDocumentType("CPF");
	p4.setTaxDocumentNumber("44444444444");
	p4.setPhoneCountry("55");
	p4.setPhoneAreaCode("11");
	p4.setPhoneNumber("66778899");

	pagamentoArray.adiciona(p4);

	for(int y = 0; y < nuCasos; y++){
		
		pagamentoAux = retornaPagamento(y);
		
		infoPagamento [y] = 
	            		 "{\"installmentCount\": "           + pagamentoAux.getInstallmentCount()    + ","
	    				+ "\"statementDescriptor\": " + "\"" + pagamentoAux.getStatementDescriptor() + "\"" + ","
	    				+ "\"fundingInstrument\": {"
	    				+ "\"method\": "              + "\"" + pagamentoAux.getMethod()              + "\"" + ","
	    				+ "\"creditCard\": {"
	    				+ "\"hash\": "                + "\"" + pagamentoAux.getCreditCardHash()      + "\"" + ","
	    				+ "\"store\": "                      + pagamentoAux.getStore()               + ","	  
	    				+ "\"holder\": {"
	    				+ "\"fullname\": "            + "\"" + pagamentoAux.getFullname()            + "\"" + "," 
	    				+ "\"birthdate\": "           + "\"" + pagamentoAux.getBirthdate()           + "\"" + ","
	    				+ "\"taxDocument\": {"
	    				+ "\"type\":"                 + "\"" + pagamentoAux.getTaxDocumentType()     + "\"" + ","
	    				+ "\"number\":"               + "\"" + pagamentoAux.getTaxDocumentNumber()   + "\"" + "},"
	    				+ "\"phone\": {"
	    				+ "\"countryCode\":"          + "\"" + pagamentoAux.getPhoneCountry()        + "\"" + ","
	    				+ "\"areaCode\":"             + "\"" + pagamentoAux.getPhoneAreaCode()       + "\"" + ","
	    				+ "\"number\":"               + "\"" + pagamentoAux.getPhoneNumber()         + "\"" + "}}}}}";
				 	 	 
	}

	}

	public Pagamento retornaPagamento(int posicao) {
		return pagamentoArray.pega(posicao);
	}	
	
	public int retornaTamanho() {
		return nuCasos;
	}
}


