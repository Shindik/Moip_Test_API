package Moip;

import static com.jayway.restassured.RestAssured.baseURI;
import static com.jayway.restassured.RestAssured.given;

import org.junit.Test;

import com.jayway.restassured.response.Response;

public class CriarPagamentoDuplicado {

	MassaPagamentoDuplicado p1 = new MassaPagamentoDuplicado();
	Acesso p2 = new Acesso ();
	int caso = 0;
	
	@Test
	public void CriarPagamentoDuplicadoMain(ListaPedidos lista) {

		System.out.println("- SCRIPT 'CriarPagamentoDuplicado': Inicio");
		System.out.println("  ");
		
		for (int y = 0; y < p1.retornaTamanho(); y++) {

			String idPedido = lista.pega(y);
			caso = y + 1;
			
			baseURI = "https://sandbox.moip.com.br/v2/orders/" + idPedido + "/payments"; 
			
			// Criando o Pagamento
			Response result = 
						given()
							.contentType("application/json")
							.header("Authorization","Basic " + p2.CodeHash)
						.when()
							.body(p1.infoPagamento[y])
							.post("/")
						.then()
							.assertThat()
							.statusCode(400)
						.extract()
							.response();
			
			System.out.println("  - Caso de Teste: " + caso + ".");
			System.out.println("    " + p1.infoPagamento[y]);
			System.out.println("    ReturnCode:    400.");
			System.out.println("    DescricaoErro: Já existe um pagamento realizado com cartão de crédito.");
			System.out.println("    Caso Finalizado com Sucesso!");
			String jsonAsString = result.asString();
			System.out.println("    O retorno da requisicao foi: " + jsonAsString);

		}
		
		System.out.println("  ");
		System.out.println("- SCRIPT 'CriarPagamentoDuplicado': Fim");
	}
}
	