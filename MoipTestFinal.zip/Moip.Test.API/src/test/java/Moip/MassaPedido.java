package Moip;

public class MassaPedido {
	
	
	private int nuCasos = 4; //numero de casos
	public String infoPedido [] = new String [nuCasos];;
	
	private Pedido p1 = new Pedido();
	private Pedido p2 = new Pedido();
	private Pedido p3 = new Pedido();
	private Pedido p4 = new Pedido();
	private Pedido pedidoAux = new Pedido();
	
	public VetorPedido pedidoArray = new VetorPedido();
	
		public MassaPedido () {
			
			// - Caso 1 Sem Addition e Sem Discount 
			
			p1.setOwnId("ORD-000001");	
			p1.setAmountCurrency("BRL");
			p1.setAmountSubShipping("10000");
			p1.setAmountSubaddition("0");
			p1.setAmountSubdiscount("0");
			p1.setItemsProduct("Computador PC");
			p1.setItemsQuantity("2");
			p1.setItemsDetail("mais infos....");
			p1.setItemsPrice("200000");	
			p1.setCustOwnId("CUS-00001");
			p1.setCustFullname("Cliente Teste 01");
			p1.setCustEmail("clienteteste01@gmail.com");
			p1.setCustBirthDate("1988-12-30");
			p1.setTaxDocumentType("CPF");
			p1.setTaxDocumentNumber("22222222222");
			p1.setPhoneCountryCode("55");
			p1.setPhoneAreaCode("11");
			p1.setPhoneNumber("66778899");
			p1.setShippingAddressCity("Sao Paulo");
			p1.setShippingAddressComplement("8");
			p1.setShippingAddressDistrict("Itaim");
			p1.setShippingAddressStreet("Avenida Faria Lima");
			p1.setShippingAddressNumber("111");
			p1.setShippingAddressZipCode("09920451");
			p1.setShippingAddressState("SP");
			p1.setShippingAddressCountry("BR");
		
			pedidoArray.adiciona(p1);


			// - Caso 2 Com Addition Sem discount
			
			p2.setOwnId("ORD-000002");	
			p2.setAmountCurrency("BRL");
			p2.setAmountSubShipping("2000");
			p2.setAmountSubaddition("1000");
			p2.setAmountSubdiscount("0");
			p2.setItemsProduct("Mouse Gamer");
			p2.setItemsQuantity("1");
			p2.setItemsDetail("mais infos....");
			p2.setItemsPrice("10000");	
			p2.setCustOwnId("CUS-00001");
			p2.setCustFullname("Cliente Teste 01");
			p2.setCustEmail("clienteteste01@gmail.com");
			p2.setCustBirthDate("1988-12-30");
			p2.setTaxDocumentType("CPF");
			p2.setTaxDocumentNumber("22222222222");
			p2.setPhoneCountryCode("55");
			p2.setPhoneAreaCode("11");
			p2.setPhoneNumber("66778899");
			p2.setShippingAddressCity("Sao Paulo");
			p2.setShippingAddressComplement("8");
			p2.setShippingAddressDistrict("Itaim");
			p2.setShippingAddressStreet("Avenida Faria Lima");
			p2.setShippingAddressNumber("111");
			p2.setShippingAddressZipCode("09920451");
			p2.setShippingAddressState("SP");
			p2.setShippingAddressCountry("BR");

			pedidoArray.adiciona(p2);

			// - Caso 3 Sem Addition e Com Discount
			
			p3.setOwnId("ORD-000003");	
			p3.setAmountCurrency("BRL");
			p3.setAmountSubShipping("2100");
			p3.setAmountSubaddition("0");
			p3.setAmountSubdiscount("100");
			p3.setItemsProduct("Teclado Gamer");
			p3.setItemsQuantity("1");
			p3.setItemsDetail("mais infos....");
			p3.setItemsPrice("10000");	
			p3.setCustOwnId("CUS-00001");
			p3.setCustFullname("Cliente Teste 01");
			p3.setCustEmail("clienteteste01@gmail.com");
			p3.setCustBirthDate("1988-12-30");
			p3.setTaxDocumentType("CPF");
			p3.setTaxDocumentNumber("22222222222");
			p3.setPhoneCountryCode("55");
			p3.setPhoneAreaCode("11");
			p3.setPhoneNumber("66778899");
			p3.setShippingAddressCity("Sao Paulo");
			p3.setShippingAddressComplement("8");
			p3.setShippingAddressDistrict("Itaim");
			p3.setShippingAddressStreet("Avenida Faria Lima");
			p3.setShippingAddressNumber("111");
			p3.setShippingAddressZipCode("09920451");
			p3.setShippingAddressState("SP");
			p3.setShippingAddressCountry("BR");

			pedidoArray.adiciona(p3);

			// - Caso 3 Com Addition e Com Discount (
			
			p4.setOwnId("ORD-000004");	
			p4.setAmountCurrency("BRL");
			p4.setAmountSubShipping("5000");
			p4.setAmountSubaddition("1000");
			p4.setAmountSubdiscount("3000");
			p4.setItemsProduct("Headset Gamer");
			p4.setItemsQuantity("1");
			p4.setItemsDetail("mais infos....");
			p4.setItemsPrice("10000");	
			p4.setCustOwnId("CUS-00001");
			p4.setCustFullname("Cliente Teste 01");
			p4.setCustEmail("clienteteste01@gmail.com");
			p4.setCustBirthDate("1988-12-30");
			p4.setTaxDocumentType("CPF");
			p4.setTaxDocumentNumber("22222222222");
			p4.setPhoneCountryCode("55");
			p4.setPhoneAreaCode("11");
			p4.setPhoneNumber("66778899");
			p4.setShippingAddressCity("Sao Paulo");
			p4.setShippingAddressComplement("8");
			p4.setShippingAddressDistrict("Itaim");
			p4.setShippingAddressStreet("Avenida Faria Lima");
			p4.setShippingAddressNumber("111");
			p4.setShippingAddressZipCode("09920451");
			p4.setShippingAddressState("SP");
			p4.setShippingAddressCountry("BR");

			pedidoArray.adiciona(p4);
			
			// Fim dos Casos
			
		for(int y = 0; y < nuCasos; y++){
			
			pedidoAux = retornaPedido(y);
			
			infoPedido [y] = 
		             "{\"ownId\": "      + "\"" + pedidoAux.getOwnId()                     + "\"" + ","
					+ "\"amount\": {"
					+ "\"currency\": "   + "\"" + pedidoAux.getAmountCurrency()            + "\"" + ","
					+ "\"subtotals\": {"
					+ "\"shipping\": "   + "\"" + pedidoAux.getAmountSubShipping()         + "\"" + "," 
					+ "\"addition\": "   + "\"" + pedidoAux.getAmountSubaddition()         + "\"" + "," 
					+ "\"discount\": "   + "\"" + pedidoAux.getAmountSubdiscount()         + "\"" + "}}," 
					+ "\"items\": [{"
					+ "\"product\": "    + "\"" + pedidoAux.getItemsProduct()              + "\"" + ","
					+ "\"quantity\": "   + "\"" + pedidoAux.getItemsQuantity()             + "\"" + ","
					+ "\"detail\": "     + "\"" + pedidoAux.getItemsDetail()               + "\"" + ","
					+ "\"price\": "      + "\"" + pedidoAux.getItemsPrice()                + "\"" + "}],"
		            + "\"customer\": {"
			        + "\"ownId\": "      + "\"" + pedidoAux.getCustOwnId()                 + "\"" + "," 
					+ "\"fullname\": "   + "\"" + pedidoAux.getCustFullname()              + "\"" + "," 
					+ "\"email\":"       + "\"" + pedidoAux.getCustEmail()                 + "\"" + ","
					+ "\"birthDate\":"   + "\"" + pedidoAux.getCustBirthDate()             + "\"" + ","
					+ "\"taxDocument\": {"
					+ "\"type\":"        + "\"" + pedidoAux.getTaxDocumentType()           + "\"" + ","
					+ "\"number\":"      + "\"" + pedidoAux.getTaxDocumentNumber()         + "\"" + "},"
					+ "\"phone\": {"
					+ "\"countryCode\":" + "\"" + pedidoAux.getPhoneCountryCode()          + "\"" + ","
					+ "\"areaCode\":"    + "\"" + pedidoAux.getPhoneAreaCode()             + "\"" + ","
					+ "\"number\":"      + "\"" + pedidoAux.getPhoneNumber()               + "\"" + "},"
					+ "\"shippingAddress\": {"
					+ "\"city\":"        + "\"" + pedidoAux.getShippingAddressCity()       + "\"" + ","
					+ "\"complement\":"  + "\"" + pedidoAux.getShippingAddressComplement() + "\"" + ","
					+ "\"district\":"    + "\"" + pedidoAux.getShippingAddressDistrict()   + "\"" + ","
					+ "\"street\":"      + "\"" + pedidoAux.getShippingAddressStreet()     + "\"" + ","
					+ "\"streetNumber\":"+ "\"" + pedidoAux.getShippingAddressNumber()     + "\"" + ","
					+ "\"zipCode\":"     + "\"" + pedidoAux.getShippingAddressZipCode()    + "\"" + ","
					+ "\"state\":"       + "\"" + pedidoAux.getShippingAddressState()      + "\"" + ","
					+ "\"country\":"     + "\"" + pedidoAux.getShippingAddressCountry()    + "\"" + "}}}";
				 	 
		}

	}

		public Pedido retornaPedido(int posicao) {
			return pedidoArray.pega(posicao);
		}	
		
		public int retornaTamanho() {
			return nuCasos;
		}
}


