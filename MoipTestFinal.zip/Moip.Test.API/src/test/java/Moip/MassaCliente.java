package Moip;


public class MassaCliente {
	private int nuCasos = 2; //numero de casos
	public String informacoes [] = new String [nuCasos];;
	
	private Cliente c1 = new Cliente();
	private Cliente c2 = new Cliente();
	private Cliente clienteAux = new Cliente();
	
	public VetorCliente clienteArray = new VetorCliente();

	
	public MassaCliente () {

		// - Caso 1
		
		c1.setOwnId("CUSTESTE00000021");
		c1.setFullname("Cliente Teste 01");
		c1.setEmail("clienteteste01@gmail.com");
		c1.setBirthDate("1988-01-01");
		c1.setTaxDocumentType("CPF");
		c1.setTaxDocumentNumber("22222222222");
		c1.setPhoneCountry("55");
		c1.setPhoneAreaCode("11");
		c1.setPhoneNumber("66778899");
		c1.setShippingAddressCity("Sao Paulo");
		c1.setShippingAddressComplement("8");
		c1.setShippingAddressDistrict("Itam");
		c1.setShippingAddressStreet("Avenida Faria Lima");
		c1.setShippingAddressNumber("2927");
		c1.setShippingAddressZipCode("01234000");
		c1.setShippingAddressState("SP");
		c1.setShippingAddressCountry("BR");
	
		clienteArray.adiciona(c1);

		// - Caso 2
	
		c2.setOwnId("CUSTESTE00000022");
		c2.setFullname("Cliente Teste 02");
		c2.setEmail("clienteteste02@gmail.com");
		c2.setBirthDate("1988-01-01");
		c2.setTaxDocumentType("CPF");
		c2.setTaxDocumentNumber("22222222222");
		c2.setPhoneCountry("55");
		c2.setPhoneAreaCode("11");
		c2.setPhoneNumber("66778899");
		c2.setShippingAddressCity("Sao Paulo");
		c2.setShippingAddressComplement("8");
		c2.setShippingAddressDistrict("Itam");
		c2.setShippingAddressStreet("Avenida Faria Lima");
		c2.setShippingAddressNumber("2927");
		c2.setShippingAddressZipCode("01234000");
		c2.setShippingAddressState("SP");
		c2.setShippingAddressCountry("BR");

		clienteArray.adiciona(c2);
	
		
		// Fim dos Casos
	
		for(int y = 0; y < nuCasos; y++){
			
			clienteAux = retornaCliente(y);
			
			informacoes [y] = 
				         "{\"ownId\": "      + "\"" + clienteAux.getOwnId()                     + "\"" + "," 
						+ "\"fullname\": "   + "\"" + clienteAux.getFullname()                  + "\"" + "," 
						+ "\"email\":"       + "\"" + clienteAux.getEmail()                     + "\"" + ","
						+ "\"birthDate\":"   + "\"" + clienteAux.getBirthDate()                 + "\"" + ","
						+ "\"taxDocument\": {"
						+ "\"type\":"        + "\"" + clienteAux.getTaxDocumentType()           + "\"" + ","
						+ "\"number\":"      + "\"" + clienteAux.getTaxDocumentNumber()         + "\"" + "},"
						+ "\"phone\": {"
						+ "\"countryCode\":" + "\"" + clienteAux.getPhoneCountry()              + "\"" + ","
						+ "\"areaCode\":"    + "\"" + clienteAux.getPhoneAreaCode()             + "\"" + ","
						+ "\"number\":"      + "\"" + clienteAux.getPhoneNumber()               + "\"" + "},"
						+ "\"shippingAddress\": {"
						+ "\"city\":"        + "\"" + clienteAux.getShippingAddressCity()       + "\"" + ","
						+ "\"complement\":"  + "\"" + clienteAux.getShippingAddressComplement() + "\"" + ","
						+ "\"district\":"    + "\"" + clienteAux.getShippingAddressDistrict()   + "\"" + ","
						+ "\"street\":"      + "\"" + clienteAux.getShippingAddressStreet()     + "\"" + ","
						+ "\"streetNumber\":"+ "\"" + clienteAux.getShippingAddressNumber()     + "\"" + ","
						+ "\"zipCode\":"     + "\"" + clienteAux.getShippingAddressZipCode()    + "\"" + ","
						+ "\"state\":"       + "\"" + clienteAux.getShippingAddressState()      + "\"" + ","
						+ "\"country\":"     + "\"" + clienteAux.getShippingAddressCountry()    + "\"" + "}}";
				;	 	 	 
		}

	}
	
	public Cliente retornaCliente(int posicao) {
		return clienteArray.pega(posicao);
	}	
	
	public int retornaTamanho() {
		return nuCasos;
	}
}
