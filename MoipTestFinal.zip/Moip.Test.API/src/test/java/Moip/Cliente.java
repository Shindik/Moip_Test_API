package Moip;

public class Cliente {

	private String ownId;
	private String fullname;
	private String Email;
	private String birthDate;
	private String taxDocumentType;
	private String taxDocumentNumber;
	private String phoneCountry;
	private String phoneAreaCode;
	private String phoneNumber;
	private String shippingAddressCity;
	private String shippingAddressComplement;
	private String shippingAddressDistrict;
	private String shippingAddressStreet;
	private String shippingAddressNumber;
	private String shippingAddressZipCode;
	private String shippingAddressState;
	private String shippingAddressCountry;

	public String getOwnId() {
		return ownId;
	}

	public void setOwnId(String ownId) {
		this.ownId = ownId;
	}
	
	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public String getTaxDocumentType() {
		return taxDocumentType;
	}

	public void setTaxDocumentType(String taxDocumentType) {
		this.taxDocumentType = taxDocumentType;
	}

	public String getTaxDocumentNumber() {
		return taxDocumentNumber;
	}

	public void setTaxDocumentNumber(String taxDocumentNumber) {
		this.taxDocumentNumber = taxDocumentNumber;
	}

	public String getPhoneCountry() {
		return phoneCountry;
	}

	public void setPhoneCountry(String phoneCountry) {
		this.phoneCountry = phoneCountry;
	}

	public String getPhoneAreaCode() {
		return phoneAreaCode;
	}

	public void setPhoneAreaCode(String phoneAreaCode) {
		this.phoneAreaCode = phoneAreaCode;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getShippingAddressCity() {
		return shippingAddressCity;
	}

	public void setShippingAddressCity(String shippingAddressCity) {
		this.shippingAddressCity = shippingAddressCity;
	}

	public String getShippingAddressComplement() {
		return shippingAddressComplement;
	}

	public void setShippingAddressComplement(String shippingAddressComplement) {
		this.shippingAddressComplement = shippingAddressComplement;
	}

	public String getShippingAddressDistrict() {
		return shippingAddressDistrict;
	}

	public void setShippingAddressDistrict(String shippingAddressDistrict) {
		this.shippingAddressDistrict = shippingAddressDistrict;
	}

	public String getShippingAddressStreet() {
		return shippingAddressStreet;
	}

	public void setShippingAddressStreet(String shippingAddressStreet) {
		this.shippingAddressStreet = shippingAddressStreet;
	}

	public String getShippingAddressNumber() {
		return shippingAddressNumber;
	}

	public void setShippingAddressNumber(String shippingAddressNumber) {
		this.shippingAddressNumber = shippingAddressNumber;
	}

	public String getShippingAddressZipCode() {
		return shippingAddressZipCode;
	}

	public void setShippingAddressZipCode(String shippingAddressZipCode) {
		this.shippingAddressZipCode = shippingAddressZipCode;
	}

	public String getShippingAddressState() {
		return shippingAddressState;
	}

	public void setShippingAddressState(String shippingAddressState) {
		this.shippingAddressState = shippingAddressState;
	}

	public String getShippingAddressCountry() {
		return shippingAddressCountry;
	}

	public void setShippingAddressCountry(String shippingAddressCountry) {
		this.shippingAddressCountry = shippingAddressCountry;
	}

}
