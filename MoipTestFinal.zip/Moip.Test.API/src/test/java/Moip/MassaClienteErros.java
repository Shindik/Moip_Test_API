package Moip;

public class MassaClienteErros {
	
	private int nuCasos = 7; //numero de erros previsto na documentacao
	public String informacoes [] = new String [nuCasos];;
	
	private Cliente c1 = new Cliente(); // null    OwnId    - O ID não foi informado 
	private Cliente c2 = new Cliente(); // null    Fullname - O nome não foi informado
	private Cliente c3 = new Cliente(); // Invalid Fullname - O nome informado não é válido
	private Cliente c4 = new Cliente(); // Invalid Fullname - O nome informado não pode conter só números
	private Cliente c5 = new Cliente(); // null    Email    - O e-mail não foi informado
	private Cliente c6 = new Cliente(); // Invalid Email    - O e-mail informado é inválido
	private Cliente c7 = new Cliente(); // null BirthDate   - A data de nascimento informada é inválida
	private Cliente clienteAux = new Cliente();
	
	public VetorCliente clienteArray = new VetorCliente();

	
	public MassaClienteErros () {

		// - Caso OwnId Null ja testado
		
		c1.setOwnId("");
		c1.setFullname("Teste Erro Null Id");
		c1.setEmail("testeerro1@gmail.com");
		c1.setBirthDate("1988-01-01");
		c1.setTaxDocumentType("CPF");
		c1.setTaxDocumentNumber("22222222222");
		c1.setPhoneCountry("55");
		c1.setPhoneAreaCode("11");
		c1.setPhoneNumber("66778899");
		c1.setShippingAddressCity("Sao Paulo");
		c1.setShippingAddressComplement("8");
		c1.setShippingAddressDistrict("Itam");
		c1.setShippingAddressStreet("Avenida Faria Lima");
		c1.setShippingAddressNumber("2927");
		c1.setShippingAddressZipCode("01234000");
		c1.setShippingAddressState("SP");
		c1.setShippingAddressCountry("BR");
	
		clienteArray.adiciona(c1);

		// - Caso 1
	
		c2.setOwnId("CUS-00003");
		c2.setFullname("");
		c2.setEmail("testeerro2@gmail.com");
		c2.setBirthDate("1988-01-01");
		c2.setTaxDocumentType("CPF");
		c2.setTaxDocumentNumber("22222222222");
		c2.setPhoneCountry("55");
		c2.setPhoneAreaCode("11");
		c2.setPhoneNumber("66778899");
		c2.setShippingAddressCity("Sao Paulo");
		c2.setShippingAddressComplement("8");
		c2.setShippingAddressDistrict("Itam");
		c2.setShippingAddressStreet("Avenida Faria Lima");
		c2.setShippingAddressNumber("2927");
		c2.setShippingAddressZipCode("01234000");
		c2.setShippingAddressState("SP");
		c2.setShippingAddressCountry("BR");;
	
		clienteArray.adiciona(c2);

		// - Caso 2
	
		c3.setOwnId("CUS-00003");
		c3.setFullname("@@@@@ @@@@@ @@@@@@");
		c3.setEmail("testeerro3@gmail.com");
		c3.setBirthDate("1988-01-01");
		c3.setTaxDocumentType("CPF");
		c3.setTaxDocumentNumber("22222222222");
		c3.setPhoneCountry("55");
		c3.setPhoneAreaCode("11");
		c3.setPhoneNumber("66778899");
		c3.setShippingAddressCity("Sao Paulo");
		c3.setShippingAddressComplement("8");
		c3.setShippingAddressDistrict("Itam");
		c3.setShippingAddressStreet("Avenida Faria Lima");
		c3.setShippingAddressNumber("2927");
		c3.setShippingAddressZipCode("01234000");
		c3.setShippingAddressState("SP");
		c3.setShippingAddressCountry("BR");;
	
		clienteArray.adiciona(c3);

		// - Caso 3
	
		c4.setOwnId("CUS-00003");
		c4.setFullname("123456789");
		c4.setEmail("testeerro4@gmail.com");
		c4.setBirthDate("1988-01-01");
		c4.setTaxDocumentType("CPF");
		c4.setTaxDocumentNumber("22222222222");
		c4.setPhoneCountry("55");
		c4.setPhoneAreaCode("11");
		c4.setPhoneNumber("66778899");
		c4.setShippingAddressCity("Sao Paulo");
		c4.setShippingAddressComplement("8");
		c4.setShippingAddressDistrict("Itam");
		c4.setShippingAddressStreet("Avenida Faria Lima");
		c4.setShippingAddressNumber("2927");
		c4.setShippingAddressZipCode("01234000");
		c4.setShippingAddressState("SP");
		c4.setShippingAddressCountry("BR");;

		clienteArray.adiciona(c4);

		// - Caso 4
	
		c5.setOwnId("CUS-00003");
		c5.setFullname("Teste Erro Null Email");
		c5.setEmail("");
		c5.setBirthDate("1988-01-01");
		c5.setTaxDocumentType("CPF");
		c5.setTaxDocumentNumber("22222222222");
		c5.setPhoneCountry("55");
		c5.setPhoneAreaCode("11");
		c5.setPhoneNumber("66778899");
		c5.setShippingAddressCity("Sao Paulo");
		c5.setShippingAddressComplement("8");
		c5.setShippingAddressDistrict("Itam");
		c5.setShippingAddressStreet("Avenida Faria Lima");
		c5.setShippingAddressNumber("2927");
		c5.setShippingAddressZipCode("01234000");
		c5.setShippingAddressState("SP");
		c5.setShippingAddressCountry("BR");;

		clienteArray.adiciona(c5);

		// - Caso 5
	
		c6.setOwnId("CUS-00003");
		c6.setFullname("Teste Erro Invalid Email");
		c6.setEmail("testeerro26");
		c6.setBirthDate("1988-01-01");
		c6.setTaxDocumentType("CPF");
		c6.setTaxDocumentNumber("22222222222");
		c6.setPhoneCountry("55");
		c6.setPhoneAreaCode("11");
		c6.setPhoneNumber("66778899");
		c6.setShippingAddressCity("Sao Paulo");
		c6.setShippingAddressComplement("8");
		c6.setShippingAddressDistrict("Itam");
		c6.setShippingAddressStreet("Avenida Faria Lima");
		c6.setShippingAddressNumber("2927");
		c6.setShippingAddressZipCode("01234000");
		c6.setShippingAddressState("SP");
		c6.setShippingAddressCountry("BR");;
	
		clienteArray.adiciona(c6);

		// - Caso 6
	
		c7.setOwnId("CUS-00003");
		c7.setFullname("Teste Erro Invalid BirthDate");
		c7.setEmail("testeerro2@gmail.com");
		c7.setBirthDate("1988-00-01");
		c7.setTaxDocumentType("CPF");
		c7.setTaxDocumentNumber("22222222222");
		c7.setPhoneCountry("55");
		c7.setPhoneAreaCode("11");
		c7.setPhoneNumber("66778899");
		c7.setShippingAddressCity("Sao Paulo");
		c7.setShippingAddressComplement("8");
		c7.setShippingAddressDistrict("Itam");
		c7.setShippingAddressStreet("Avenida Faria Lima");
		c7.setShippingAddressNumber("2927");
		c7.setShippingAddressZipCode("01234000");
		c7.setShippingAddressState("SP");
		c7.setShippingAddressCountry("BR");;
	
		clienteArray.adiciona(c7);

		
		// Fim dos Casos
	
		for(int y = 0; y < nuCasos; y++){
			
			clienteAux = retornaCliente(y);
			
			informacoes [y] = 
				         "{\"ownId\": "      + "\"" + clienteAux.getOwnId()                     + "\"" + "," 
						+ "\"fullname\": "   + "\"" + clienteAux.getFullname()                  + "\"" + "," 
						+ "\"email\":"       + "\"" + clienteAux.getEmail()                     + "\"" + ","
						+ "\"birthDate\":"   + "\"" + clienteAux.getBirthDate()                 + "\"" + ","
						+ "\"taxDocument\": {"
						+ "\"type\":"        + "\"" + clienteAux.getTaxDocumentType()           + "\"" + ","
						+ "\"number\":"      + "\"" + clienteAux.getTaxDocumentNumber()         + "\"" + "},"
						+ "\"phone\": {"
						+ "\"countryCode\":" + "\"" + clienteAux.getPhoneCountry()              + "\"" + ","
						+ "\"areaCode\":"    + "\"" + clienteAux.getPhoneAreaCode()             + "\"" + ","
						+ "\"number\":"      + "\"" + clienteAux.getPhoneNumber()               + "\"" + "},"
						+ "\"shippingAddress\": {"
						+ "\"city\":"        + "\"" + clienteAux.getShippingAddressCity()       + "\"" + ","
						+ "\"complement\":"  + "\"" + clienteAux.getShippingAddressComplement() + "\"" + ","
						+ "\"district\":"    + "\"" + clienteAux.getShippingAddressDistrict()   + "\"" + ","
						+ "\"street\":"      + "\"" + clienteAux.getShippingAddressStreet()     + "\"" + ","
						+ "\"streetNumber\":"+ "\"" + clienteAux.getShippingAddressNumber()     + "\"" + ","
						+ "\"zipCode\":"     + "\"" + clienteAux.getShippingAddressZipCode()    + "\"" + ","
						+ "\"state\":"       + "\"" + clienteAux.getShippingAddressState()      + "\"" + ","
						+ "\"country\":"     + "\"" + clienteAux.getShippingAddressCountry()    + "\"" + "}}";
				;	 	 	 
		}

	}
	
	public Cliente retornaCliente(int posicao) {
		return clienteArray.pega(posicao);
	}	
	
	public int retornaTamanho() {
		return nuCasos;
	}
}
