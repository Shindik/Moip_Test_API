package Moip;


public class Scheadule {

	public static void main(String[] args) {

		ListaPedidos pedidos = new ListaPedidos();
		ListaPagamentos pagamentos = new ListaPagamentos();
		
		IncluirCliente                	step1  = new IncluirCliente ();
		IncluirClienteDuplicado       	step2  = new IncluirClienteDuplicado ();
		IncluirClienteErros            	step3  = new IncluirClienteErros ();
		CriarPedido                		step4  = new CriarPedido ();
		ConsultarPedidoInexistente      	step5  = new ConsultarPedidoInexistente ();
		CriarPagamento                  	step6  = new CriarPagamento();
		CriarPagamentoDuplicado    	    step7  = new CriarPagamentoDuplicado();
		CriarPagamentoPedidoInexistente 	step8  = new CriarPagamentoPedidoInexistente();
//		CapturarPagamento             	step9  = new CapturarPagamento();
//		CancelarPagamento             	step10 = new CancelarPagamento();
		
		System.out.println("- TESTE API MOIP - CLIENTE/PEDIDO/PEGAMENTO: Inicio");
		System.out.println("  ");
		
		step1.IncluirClienteMain();
			System.out.println(" "); //Espacamento entre scripts
			System.out.println(" "); //Espacamento entre scripts
			
		step2.IncluirClienteDuplicadoMain();		
			System.out.println(" "); //Espacamento entre scripts
			System.out.println(" "); //Espacamento entre scripts
			
		step3.IncluirClienteErrosMain();		
			System.out.println(" "); //Espacamento entre scripts
			System.out.println(" "); //Espacamento entre scripts
	
		pedidos = step4.CriarPedidoMain();
			System.out.println(" "); //Espacamento entre scripts
			System.out.println(" "); //Espacamento entre scripts
			
		step5.ConsultarPedidoInexistenteMain();
			System.out.println(" "); //Espacamento entre scripts
			System.out.println(" "); //Espacamento entre scripts
			
		pagamentos = step6.CriarPagamentoMain(pedidos);
			System.out.println(" "); //Espacamento entre scripts
			System.out.println(" "); //Espacamento entre scripts

		step7.CriarPagamentoDuplicadoMain(pedidos);
			System.out.println(" "); //Espacamento entre scripts
			System.out.println(" "); //Espacamento entre scripts
			
		step8.CriarPagamentoPedidoInexistenteMain();
			System.out.println(" "); //Espacamento entre scripts
/*			System.out.println(" "); //Espacamento entre scripts
 *		
 *******************************************************************************************
 *      SCRIPTS NAO IMPLEMENTADOS - NAO FOI POSSIVEL CRIAR PAGAMENTOS 'PRE_AUTHORIZED'
 *      		   MESMO UTILIZANDO O CAMPO 'delayCapture' O STATUS MANTEM 'IN_ANALYSIS' 
 *******************************************************************************************
 *
 *		step9.CapturarPagamentoMain(pagamentos);
 *			System.out.println(" "); //Espacamento entre scripts
 *			System.out.println(" "); //Espacamento entre scripts
 *
 *		step10.CancelarrPagamentoMain(pagamentos);
 *			System.out.println(" "); //Espacamento entre scripts
 */				
			System.out.println("- TESTE API MOIP - CLIENTE/PEDIDO/PEGAMENTO: FIM");
	}

}
