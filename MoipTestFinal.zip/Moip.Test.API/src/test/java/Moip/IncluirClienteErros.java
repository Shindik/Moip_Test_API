package Moip;

import static com.jayway.restassured.RestAssured.baseURI;
import static com.jayway.restassured.RestAssured.given;

import org.junit.Test;

import com.jayway.restassured.response.Response;

public class IncluirClienteErros {
	private boolean isContains = false;
	private int cont = 0;
	
	
	@Test
	public void IncluirClienteErrosMain() {
		
		System.out.println("- SCRIPT 'IncluirClienteErros': Inicio");
		
		MassaClienteErros massa = new MassaClienteErros(); //Massa Duplicada
		Acesso acesso = new Acesso();
		
		// "https://sandbox.moip.com.br/v2/customers";
		baseURI = acesso.AcessoCliente;

		for (int y = 0; y < massa.retornaTamanho(); y++) {

			int caso = y + 1;
			System.out.println(" "); //Espacamento entre scripts
			System.out.println("  - Caso de Teste: " + caso + ".");
			System.out.println("    " + massa.informacoes[y]);
					
			Response result = 
					given()
						.contentType("application/json")
						.header("Authorization", "Basic " + acesso.CodeHash)
					.when()
						.body(massa.informacoes[y])
						.post("/")
					.then()
						.assertThat()
						.statusCode(400)
					.extract()
						.response();

			String jsonAsString = result.asString();
			
			
			VerificaContemCodigoErro(jsonAsString);

			int valorErro = 0;
			valorErro = y + 1;
			
			if (cont == valorErro) {
				
				switch(cont) {
					case 1:
						RetornoErro0001(jsonAsString);
						break;
					case 2:
						RetornoErro0002(jsonAsString);
						break;
					case 3:
						//Sistema não apresenta o erro
						RetornoErro0003(jsonAsString);
						break;
					case 4:
						//Sistema não apresenta o erro
						RetornoErro0004(jsonAsString);
						break;
					case 5:
						RetornoErro0005(jsonAsString);
						break;
					case 6:
						RetornoErro0006(jsonAsString);
						break;
					case 7:
						RetornoErro0007(jsonAsString);
								
						break;
					default:
						System.out.println("    Swith Case Default!!!!\n" + 
											"    Erro nao previsto !!!!\n" +
											"    O retorno da requisicao foi: " + jsonAsString);
				} 
				
			} else {
				System.out.println("    Erro nao previsto!!!!\n" +
									"    O retorno da requisicao foi: " + jsonAsString);
			}
			
			isContains = false;
			cont = 1;
		}

		System.out.println(" "); //Espacamento entre scripts
		System.out.println("- SCRIPT 'IncluirClienteErros': Fim");
	}

	private void RetornoErro0007(String jsonAsString) {

		System.out.println("    ReturnCode:    400.\n" + 
							"    CodigoErro:    CUS-0007.\n" + 
							"    DescricaoErro: A data de nascimento informada é inválida.\n" +
							"    Caso Finalizado com Sucesso!\n" +
							"    O retorno da requisicao foi: " + jsonAsString);
	}

	private void RetornoErro0006(String jsonAsString) {

		System.out.println("    ReturnCode:    400.\n" +
							"    CodigoErro:    CUS-0006.\n" +
							"    DescricaoErro: O e-mail informado e invalido.\n" +
							"    Caso Finalizado com Sucesso!\n" +
							"    O retorno da requisicao foi: " + jsonAsString);
	}

	private void RetornoErro0005(String jsonAsString) {

		System.out.println("    ReturnCode:    400.");
		System.out.println("    CodigoErro:    CUS-0005.");
		System.out.println("    DescricaoErro: O e-mail nao foi informado.");
		System.out.println("    Caso Finalizado com Sucesso!");
		System.out.println("    O retorno da requisicao foi: " + jsonAsString);
	}

	private void RetornoErro0004(String jsonAsString) {

		System.out.println("    ReturnCode:    400.");
		System.out.println("    CodigoErro:    CUS-0004.");
		System.out.println("    DescricaoErro: O nome informado nao pode conter so numeros.");
		System.out.println("    Caso Finalizado com Sucesso!");
		System.out.println("    O retorno da requisicao foi: " + jsonAsString);
	
	}

	private void RetornoErro0003(String jsonAsString) {

		System.out.println("    ReturnCode:    400.");
		System.out.println("    CodigoErro:    CUS-0003.");
		System.out.println("    DescricaoErro: O nome informado nao e valido.");
		System.out.println("    Caso Finalizado com Sucesso!");
		System.out.println("    O retorno da requisicao foi: " + jsonAsString);
	}

	private void RetornoErro0002(String jsonAsString) {

		System.out.println("    ReturnCode:    400.");
		System.out.println("    CodigoErro:    CUS-0002.");
		System.out.println("    DescricaoErro: O nome nao foi informado.");
		System.out.println("    Caso Finalizado com Sucesso!");
		System.out.println("    O retorno da requisicao foi: " + jsonAsString);
	}

	private void RetornoErro0001(String jsonAsString) {
		
		System.out.println("    ReturnCode:    400.");
		System.out.println("    CodigoErro:    CUS-0001.");
		System.out.println("    DescricaoErro: O identificador proprio nao foi informado.");
		System.out.println("    Caso Finalizado com Sucesso!");
		System.out.println("    O retorno da requisicao foi: " + jsonAsString);
	}

	private void VerificaContemCodigoErro(String retorno) {
		
		while (isContains != true) {

			cont++;
			isContains = retorno.contains("CUS-00"+cont);
			
			
			if (cont > 7) {
				isContains = true;
			}
		}
		
	}
	
}
