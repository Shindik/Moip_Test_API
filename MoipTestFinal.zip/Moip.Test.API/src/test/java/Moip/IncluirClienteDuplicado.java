package Moip;

import static com.jayway.restassured.RestAssured.baseURI;
import static com.jayway.restassured.RestAssured.given;

import org.junit.Test;

import com.jayway.restassured.response.Response;

public class IncluirClienteDuplicado {

	@Test
	public void IncluirClienteDuplicadoMain() {
		
		System.out.println("- SCRIPT 'IncluirClienteDuplicado': Inicio");
		
		MassaClienteDuplicado massa = new MassaClienteDuplicado(); //Massa Duplicada
		Acesso acesso = new Acesso();
		
		// "https://sandbox.moip.com.br/v2/customers";
		baseURI = acesso.AcessoCliente;

		for (int y = 0; y < massa.retornaTamanho(); y++) {

			int caso = y + 1;
			System.out.println(" "); //Espacamento entre scripts
			System.out.println("  - Caso de Teste: " + caso + ".");
			System.out.println("    " + massa.informacoes[y]);
					
			Response result = 
					given()
						.contentType("application/json")
						.header("Authorization", "Basic " + acesso.CodeHash)
					.when()
						.body(massa.informacoes[y])
						.post("/")
					.then()
						.assertThat()
						.statusCode(400)
					.extract()
						.response();
			
			System.out.println("  - Caso de Teste: " + caso + ".");
			System.out.println("    ReturnCode:    400.");
			System.out.println("    Resultado esperado.");
			System.out.println("    Caso Finalizado com Sucesso!");
			

			String jsonAsString = result.asString();
			
			System.out.println("  - Caso de Teste: " + caso + ".");
			System.out.println("    O retorno da requisicao foi: " + jsonAsString);
			System.out.println(" "); //Espacamento entre scripts

		}
		
		System.out.println("- SCRIPT 'IncluirClienteDuplicado': Fim");
	}
}