package Moip;

public class VetorCliente {
	
	  private Cliente[] clienteArray = new Cliente[100];

	  private int totalDeCliente = 0;
	  
	  public void adiciona(Cliente cliente) {
		    this.clienteArray[this.totalDeCliente] = cliente;
		    this.totalDeCliente++;
	  }

	  public Cliente pega(int posicao) {
		  return this.clienteArray[posicao];
	  }
	  
	  public int tamanho() {
		  return this.totalDeCliente;
	  }
}
