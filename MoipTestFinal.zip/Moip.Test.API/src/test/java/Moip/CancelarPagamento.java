package Moip;

import static com.jayway.restassured.RestAssured.baseURI;
import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;

import org.junit.Test;

public class CancelarPagamento {

	// *************************************************************************************
	//                       NAO FOI POSSIVEL TESTAR ESTE SCRIPT
	// *************************************************************************************
	
	
	Acesso acesso = new Acesso ();
	@Test
	public void CancelarPagamentoMain(ListaPagamentos lista) {
		
		System.out.println("- SCRIPT 'CancelarPagamento': Inicio");
		
		//Cancelar a outra metade dos pagamentos
		int tamanho = lista.retornaTamanho();
		int inicio = 0 ;
		
		if ((tamanho % 2) == 0) {
			tamanho = tamanho / 2;
			inicio = tamanho ;
		} else {
			tamanho = tamanho / 2;
			inicio = tamanho + 1;
		}
		if (inicio == 1 && tamanho == 0) {
			System.out.println("     Nao ha caso aplicavel!!");
		} else {
			for (int y = inicio; y < tamanho; y++) {
	
				int caso = y + 1;
				String idPedido = lista.pega(y);
				
				System.out.println(" "); //Espacamento
				System.out.println("    - Caso de Teste: " + caso + ".");
				
				baseURI = acesso.AcessoPagamento + "/" + idPedido + "/void";
				System.out.println("      " + baseURI);
				
				String result = 
						given()
						 	.contentType("application/json")
							.header("Authorization","Basic " + acesso.CodeHash)
						.when()
							.body("")
							.post("/")
						.then()
							.assertThat()
							.statusCode(200)
							.body("id", containsString(idPedido))
							.body("status", containsString("CANCELLED"))
						.extract()
							.path("status");
	
				System.out.println("      Pagamento Cancelado com sucesso!!");
				System.out.println("      Status: " + result);
			}
		}

		System.out.println(" "); //Espacamento
		System.out.println("- SCRIPT 'CancelarPagamento': Inicio");
		
	}
}
