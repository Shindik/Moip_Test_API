package Moip;

import static com.jayway.restassured.RestAssured.baseURI;
import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

import org.junit.Test;

public class ConsultarPedidoInexistente {
	
	@Test
	public void ConsultarPedidoInexistenteMain() {

		System.out.println("- SCRIPT 'ConsultarPedidoInexistente': Inicio");
		
		Acesso acesso = new Acesso ();
		//"https://sandbox.moip.com.br/v2/orders";	
		baseURI = acesso.AcessoPedido;
	
		given()
			.contentType("application/json")
			.header("Authorization", "Basic " + acesso.CodeHash)
		.when()
			.get("/" + "ORD-1234567890NN") //Id inexistente
		.then()
			.assertThat()
			.statusCode(404)
			.body("error", containsString("resource not found"));
			

		System.out.println(" "); //Espacamento
			
		System.out.println("    - Caso de Teste: Unico.");
		System.out.println("      Mensagem apresentada: \"resource not found\"");
		
		System.out.println(" "); //Espacamento
		System.out.println("- SCRIPT 'ConsultarPedidoInexistente': Fim");

}
}

