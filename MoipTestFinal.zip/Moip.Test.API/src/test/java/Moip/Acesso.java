package Moip;

public class Acesso {

	// CodeHash64 = Chave Token:Chave Acesso
	String CodeHash = "NVlVSkxTNEhUN0tXVk9NTFdZTU9JM05PWUdEUjZBVUQ6WVFDSDQyTE9NS1BHVVpOT1EwWUdBTkFEUURVQjRITUFYNTVXT0NSRg==";
	
	String AcessoCliente = "https://sandbox.moip.com.br/v2/customers";
	String AcessoPedido = "https://sandbox.moip.com.br/v2/orders";
	String AcessoPagamento = "https://sandbox.moip.com.br/v2/payments";
	
	String CartaoHash = "M6LA3p+CGL7TRq+xpaxZSCWupTBG4xY5eytFFP+TEWwRUpXZXYFVO7PTDEvoL5t4Suc6gE5OoYHDdRJDDHJmGyNhr6FHT3eaTBlGxq/v4a8UYylsHUqgQ87n3L46hmyHK+CuWSy9tGvnBUKT3NDcDkMgMvPlTl/hUZvuFNVzmaJQNIB5P5VzpK8UzJNX4mRo96h4//Bw+L39qPZPWwDW5+PhaJquB8gcjprbfDivK/aWJgI2nXiq+CiH+nLfqlcP3rVHDfGOOw7+M+//rI600owS7MJZQTA8IPCWXvQmTmg8YZmSMgF5E73lINB0wR+SjS5xKYZxCWLMix9G5Pp54A==";
                      
}
