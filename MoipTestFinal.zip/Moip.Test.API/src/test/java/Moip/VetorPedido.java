package Moip;

public class VetorPedido {
	  private Pedido[] pedidoArray = new Pedido[100];

	  private int totalDePedidos = 0;
	  
	  public void adiciona(Pedido pedido) {
		    this.pedidoArray[this.totalDePedidos] = pedido;
		    this.totalDePedidos++;
	  }

	  public Pedido pega(int posicao) {
		  return this.pedidoArray[posicao];
	  }
	  
	  public int tamanho() {
		  return this.totalDePedidos;
	  }
}
