package Moip;

public class MassaClienteDuplicado {
	private int nuCasos = 1; //numero de casos
	public String informacoes [] = new String [nuCasos];;
	
	private Cliente c1 = new Cliente();
	private Cliente clienteAux = new Cliente();
	
	public VetorCliente clienteArray = new VetorCliente();

	
	public MassaClienteDuplicado () {

		// Caso 1 - Duplicado
		
		c1.setOwnId("CUS-00001");
		c1.setFullname("Teste Cliente Duplicado");
		c1.setEmail("teste.cliente.dup@gmail.com");
		c1.setBirthDate("1988-01-01");
		c1.setTaxDocumentType("CPF");
		c1.setTaxDocumentNumber("22222222222");
		c1.setPhoneCountry("55");
		c1.setPhoneAreaCode("11");
		c1.setPhoneNumber("66778899");
		c1.setShippingAddressCity("Sao Paulo");
		c1.setShippingAddressComplement("8");
		c1.setShippingAddressDistrict("Itam");
		c1.setShippingAddressStreet("Avenida Faria Lima");
		c1.setShippingAddressNumber("2927");
		c1.setShippingAddressZipCode("01234000");
		c1.setShippingAddressState("SP");
		c1.setShippingAddressCountry("BR");
	
		clienteArray.adiciona(c1);
		
		// Fim dos Casos
	
		for(int y = 0; y < nuCasos; y++){
			
			clienteAux = retornaCliente(y);
			
			informacoes [y] = 
				         "{\"ownId\": "      + "\"" + clienteAux.getOwnId()                     + "\"" + "," 
						+ "\"fullname\": "   + "\"" + clienteAux.getFullname()                  + "\"" + "," 
						+ "\"email\":"       + "\"" + clienteAux.getEmail()                     + "\"" + ","
						+ "\"birthDate\":"   + "\"" + clienteAux.getBirthDate()                 + "\"" + ","
						+ "\"taxDocument\": {"
						+ "\"type\":"        + "\"" + clienteAux.getTaxDocumentType()           + "\"" + ","
						+ "\"number\":"      + "\"" + clienteAux.getTaxDocumentNumber()         + "\"" + "},"
						+ "\"phone\": {"
						+ "\"countryCode\":" + "\"" + clienteAux.getPhoneCountry()              + "\"" + ","
						+ "\"areaCode\":"    + "\"" + clienteAux.getPhoneAreaCode()             + "\"" + ","
						+ "\"number\":"      + "\"" + clienteAux.getPhoneNumber()               + "\"" + "},"
						+ "\"shippingAddress\": {"
						+ "\"city\":"        + "\"" + clienteAux.getShippingAddressCity()       + "\"" + ","
						+ "\"complement\":"  + "\"" + clienteAux.getShippingAddressComplement() + "\"" + ","
						+ "\"district\":"    + "\"" + clienteAux.getShippingAddressDistrict()   + "\"" + ","
						+ "\"street\":"      + "\"" + clienteAux.getShippingAddressStreet()     + "\"" + ","
						+ "\"streetNumber\":"+ "\"" + clienteAux.getShippingAddressNumber()     + "\"" + ","
						+ "\"zipCode\":"     + "\"" + clienteAux.getShippingAddressZipCode()    + "\"" + ","
						+ "\"state\":"       + "\"" + clienteAux.getShippingAddressState()      + "\"" + ","
						+ "\"country\":"     + "\"" + clienteAux.getShippingAddressCountry()    + "\"" + "}}";
				;	 	 	 
		}

	}
	
	public Cliente retornaCliente(int posicao) {
		return clienteArray.pega(posicao);
	}	
	
	public int retornaTamanho() {
		return nuCasos;
	}
}
