package Moip;

public class VetorPagamento {

	private Pagamento[] pagamentoArray = new Pagamento[100];

	private int totalDePedidos = 0;
	
	public void adiciona(Pagamento pagamento) {
		    this.pagamentoArray[this.totalDePedidos] = pagamento;
		    this.totalDePedidos++;
	}
	
	public Pagamento pega(int posicao) {
		  return this.pagamentoArray[posicao];
	}
	
	public int tamanho() {
		  return this.totalDePedidos;
	}
}