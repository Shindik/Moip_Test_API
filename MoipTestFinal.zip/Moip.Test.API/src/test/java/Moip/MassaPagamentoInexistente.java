package Moip;

public class MassaPagamentoInexistente {
	
	private int nuCasos = 1; //numero de casos
	Pagamento p1 = new Pagamento();
	private Pagamento pagamentoAux = new Pagamento();
	public VetorPagamento pagamentoArray = new VetorPagamento();
	String infoPagamento[] = new String [nuCasos];
	
	Acesso acesso = new Acesso();
	
public MassaPagamentoInexistente () {

	//- Caso 1
	
	p1.setInstallmentCount("1");
	p1.setStatementDescriptor("minhaLoja.com");
	p1.setMethod("CREDIT_CARD");
	p1.setCreditCardHash(acesso.CartaoHash);
	p1.setStore("true");
	p1.setFullname("Cliente Teste 01");
	p1.setBirthdate("1988-12-30");
	p1.setTaxDocumentType("CPF");
	p1.setTaxDocumentNumber("11111111111");
	p1.setPhoneCountry("55");
	p1.setPhoneAreaCode("11");
	p1.setPhoneNumber("66778899");
	
	pagamentoArray.adiciona(p1);

	for(int y = 0; y < nuCasos; y++){
		
		pagamentoAux = retornaPagamento(y);
		
		infoPagamento [y] = 
	            		 "{\"installmentCount\": "           + pagamentoAux.getInstallmentCount()    + ","
	    				+ "\"statementDescriptor\": " + "\"" + pagamentoAux.getStatementDescriptor() + "\"" + ","
	    				+ "\"fundingInstrument\": {"
	    				+ "\"method\": "              + "\"" + pagamentoAux.getMethod()              + "\"" + ","
	    				+ "\"creditCard\": {"
	    				+ "\"hash\": "                + "\"" + pagamentoAux.getCreditCardHash()      + "\"" + ","
	    				+ "\"store\": "                      + pagamentoAux.getStore()               + ","	  
	    				+ "\"holder\": {"
	    				+ "\"fullname\": "            + "\"" + pagamentoAux.getFullname()            + "\"" + "," 
	    				+ "\"birthdate\": "           + "\"" + pagamentoAux.getBirthdate()           + "\"" + ","
	    				+ "\"taxDocument\": {"
	    				+ "\"type\":"                 + "\"" + pagamentoAux.getTaxDocumentType()     + "\"" + ","
	    				+ "\"number\":"               + "\"" + pagamentoAux.getTaxDocumentNumber()   + "\"" + "},"
	    				+ "\"phone\": {"
	    				+ "\"countryCode\":"          + "\"" + pagamentoAux.getPhoneCountry()        + "\"" + ","
	    				+ "\"areaCode\":"             + "\"" + pagamentoAux.getPhoneAreaCode()       + "\"" + ","
	    				+ "\"number\":"               + "\"" + pagamentoAux.getPhoneNumber()         + "\"" + "}}}}}";
				 	 	 
	}

	}

	public Pagamento retornaPagamento(int posicao) {
		return pagamentoArray.pega(posicao);
	}	
	
	public int retornaTamanho() {
		return nuCasos;
	}
}
