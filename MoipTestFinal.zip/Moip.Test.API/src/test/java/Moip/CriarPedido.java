package Moip;

import static com.jayway.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import org.junit.Test;

public class CriarPedido {
	Acesso acesso = new Acesso ();
	ListaPedidos listaPedido = new ListaPedidos();
	int valorTotalPedido = 0;
	
	@Test
	public ListaPedidos CriarPedidoMain() {

		MassaPedido massa = new MassaPedido();
		
		
		System.out.println("- SCRIPT 'CriarPedido': Inicio");
		baseURI = acesso.AcessoPedido;//"https://sandbox.moip.com.br/v2/orders";
		
		for(int y = 0; y < massa.retornaTamanho(); y++){
						
			InclusaoPedido(y, massa);
				
		}

		System.out.println(" "); //Espacamento
		System.out.println("- SCRIPT 'CriarPedido': Fim");
		
		return listaPedido;
	}

	private void InclusaoPedido(int valor, MassaPedido massaEntrada) {

		int caso = valor + 1;
		System.out.println(" "); //Espacamento
		System.out.println("    - Caso de Teste: " + caso + ".");
		System.out.println("      " + massaEntrada.infoPedido[valor]);

		Pedido pedidoAux = new Pedido();
		pedidoAux = massaEntrada.retornaPedido(valor);
			
		//Modulo calcula total pedido (SubTotal [shipping + addition + discount] + qntd * price)
		valorTotalPedido = CalculaValorTotalPedido(pedidoAux);
			
		String result = 
				given()
				 	.contentType("application/json")
					.header("Authorization","Basic " + acesso.CodeHash)
				.when()
					.body(massaEntrada.infoPedido[valor])
					.post("/")
				.then()
					.assertThat()
					.statusCode(201)
					.body("ownId", containsString(pedidoAux.getOwnId()))
					.body("amount.total", equalTo(valorTotalPedido))
				.extract()
					.path("id");
				
		System.out.println("      - Caso  numero: " + caso + " Incluido com sucesso.");
		System.out.println("                  ID: " + result + "\n" +
				           "        Total Pedido: " + valorTotalPedido);
		
		//Valida inclusao
		ValidaIncluaoPedido(caso, pedidoAux, result);

		listaPedido.adiciona(result);
		
			
	}


	private void ValidaIncluaoPedido(int valor2, Pedido pedido, String result) {
		
		given()
			.contentType("application/json")
			.header("Authorization", "Basic " + acesso.CodeHash)
		.when()
			.get("/" + result)
		.then()
			.assertThat()
			.statusCode(200)
			.body("ownId", containsString(pedido.getOwnId()))
			.body("amount.total", equalTo(valorTotalPedido));
		
		System.out.println("      - Caso numero: " + valor2 + " Inclusao Validada!!");
		
	}
	
	private int CalculaValorTotalPedido(Pedido pedido) {
		
		int valorItens = Integer.parseInt(pedido.getItemsQuantity()) * Integer.parseInt(pedido.getItemsPrice());
		int valorSubTotal = Integer.parseInt(pedido.getAmountSubShipping()) +
							Integer.parseInt(pedido.getAmountSubaddition()) - 
							Integer.parseInt(pedido.getAmountSubdiscount());
		int totalPedido = valorItens + valorSubTotal;
		
		return totalPedido;
		
	}	
	
	
	
	
}
	


