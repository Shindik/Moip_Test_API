package Moip;

public class Pagamento {
	
	private String installmentCount;
	private String statementDescriptor;
	private String method;
	private String creditCardHash;
	private String store;
	private String fullname;
	private String birthdate;
	private String taxDocumentType;
	private String taxDocumentNumber;
	private String phoneCountry;
	private String phoneAreaCode;
	private String phoneNumber;
	

	public String getInstallmentCount() {
		return installmentCount;
	}
	
	public void setInstallmentCount(String installmentCount) {
		this.installmentCount = installmentCount;
	}
	
	public String getStatementDescriptor() {
		return statementDescriptor;
	}
	
	public void setStatementDescriptor(String statementDescriptor) {
		this.statementDescriptor = statementDescriptor;
	}
	
	public String getMethod() {
		return method;
	}
	
	public void setMethod(String method) {
		this.method = method;
	}
	
	public String getCreditCardHash() {
		return creditCardHash;
	}
	
	public void setCreditCardHash(String creditCardHash) {
		this.creditCardHash = creditCardHash;
	}
	
	public String getStore() {
		return store;
	}
	
	public void setStore(String store) {
		this.store = store;
	}
	
	public String getFullname() {
		return fullname;
	}
	
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	
	public String getBirthdate() {
		return birthdate;
	}
	
	public void setBirthdate(String birthdate) {
		this.birthdate = birthdate;
	}
	
	public String getTaxDocumentType() {
		return taxDocumentType;
	}
	
	public void setTaxDocumentType(String taxDocumentType) {
		this.taxDocumentType = taxDocumentType;
	}
	
	public String getTaxDocumentNumber() {
		return taxDocumentNumber;
	}
	
	public void setTaxDocumentNumber(String taxDocumentNumber) {
		this.taxDocumentNumber = taxDocumentNumber;
	}
	
	public String getPhoneCountry() {
		return phoneCountry;
	}
	
	public void setPhoneCountry(String phoneCountry) {
		this.phoneCountry = phoneCountry;
	}
	
	public String getPhoneAreaCode() {
		return phoneAreaCode;
	}
	
	public void setPhoneAreaCode(String phoneAreaCode) {
		this.phoneAreaCode = phoneAreaCode;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}
	
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
}
