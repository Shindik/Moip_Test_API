package Moip;

public class ListaPedidos {
	  private String[] pedidoID = new String[100];

	  private int totalDePedidos = 0;
	  
	  public void adiciona(String pedidoId) {
		    this.pedidoID[this.totalDePedidos] = pedidoId;
		    this.totalDePedidos++;
	  }

	  public String pega(int posicao) {
		  return this.pedidoID[posicao];
	  }
	  
	  public int tamanho() {
		  return this.totalDePedidos;
	  }
}
