package Moip;

import static com.jayway.restassured.RestAssured.baseURI;
import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;

import org.junit.Test;

public class CriarPagamentoPedidoInexistente {

	MassaPagamentoInexistente massa = new MassaPagamentoInexistente();
	Acesso p2 = new Acesso();
	
	@Test
	public void CriarPagamentoPedidoInexistenteMain() {

		System.out.println("- SCRIPT 'CriarPagamentoPedidoInexistente': Inicio");
		
		for (int y = 0; y < 1; y++) { 
			
			baseURI = "https://sandbox.moip.com.br/v2/orders/ORD-1234567890NN/payments";
			 given().contentType("application/json")
					.header("Authorization", "Basic "+ p2.CodeHash)
				.when()
					.body(massa.infoPagamento[y])
					.post("/")
				.then()
					.assertThat()
					.statusCode(404)
					.body("error", containsString("resource not found"));

				System.out.println(" "); //Espacamento
					
				System.out.println("    - Caso de Teste: Unico.");
				System.out.println("      Mensagem apresentada: \"resource not found\"");
				
				System.out.println(" "); //Espacamento

		}
		System.out.println("- SCRIPT 'CriarPagamentoPedidoInexistente': Fim");
	}
}	

