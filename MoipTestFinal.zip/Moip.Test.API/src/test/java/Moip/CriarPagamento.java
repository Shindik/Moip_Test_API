package Moip;

import static com.jayway.restassured.RestAssured.baseURI;
import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;

import org.junit.Test;

public class CriarPagamento {

	Acesso acesso = new Acesso ();
	ListaPagamentos listaPagamentos = new ListaPagamentos();
	
	@Test
	public ListaPagamentos CriarPagamentoMain(ListaPedidos lista) {
		
		MassaPagamento massa = new MassaPagamento();

		System.out.println("- SCRIPT 'CriarPagamento': Inicio");
		
		for (int y = 0; y < massa.retornaTamanho(); y++) {

			int caso = y + 1;
			String idPedido = lista.pega(y);
			
			System.out.println(" "); //Espacamento
			System.out.println("    - Caso de Teste: " + caso + " " + massa.infoPagamento[y]);
			baseURI = "https://sandbox.moip.com.br/v2/orders/" + idPedido + "/payments";
			System.out.println("      " + baseURI);
			
			// Modulo de Inclusao de Pagamento
			InclusaoPagamento(y, caso, massa);

			
		}

		System.out.println(" "); //Espacamento
		System.out.println("- SCRIPT 'CriarPagamento': Inicio");
		
		return listaPagamentos;
		
	}
	
	private void InclusaoPagamento(int y, int caso, MassaPagamento massa) {

		String result = 
				given()
					.contentType("application/json")
					.header("Authorization", "Basic "+ acesso.CodeHash)
				.when()
					.body(massa.infoPagamento[y])
					.post("/")
				.then()
					.assertThat()
					.statusCode(201)
				.extract()
					.path("id");
		
		
		System.out.println("      - Caso  numero: " + caso + " Incluido com sucesso.");
		System.out.println("                  ID: " + result);

		// Modulo Validacao Inclusao Pagamento
		
		ValidaInclusaoPagamento(result, caso);

		listaPagamentos.adiciona(result);
		
	}

	private void ValidaInclusaoPagamento(String result, int caso) {

		given()
			.contentType("application/json")
			.header("Authorization", "Basic " + acesso.CodeHash)
		.when()
			.get("https://sandbox.moip.com.br/v2/payments/" + result)
		.then()
			.assertThat()
			.statusCode(200)
			.body("id", containsString(result));

		System.out.println("      - Caso numero: " + caso + " Inclusão Validada!!");
	}
}
	

