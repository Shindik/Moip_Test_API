package Moip;

import static com.jayway.restassured.RestAssured.baseURI;
import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;

import org.junit.Test;

public class CapturarPagamento {
	
	// *************************************************************************************
	//                       NAO FOI POSSIVEL TESTAR ESTE SCRIPT
	// *************************************************************************************
	
	
	Acesso acesso = new Acesso ();
	@Test
	public void CapturarPagamentoMain(ListaPagamentos lista) {
		
		System.out.println("- SCRIPT 'CapturarPagamento': Inicio");
		
		//capturar metade dos pagamentos para Capturar
		int tamanho = lista.retornaTamanho();
		
		if ((tamanho % 2) ==0) {
			tamanho = tamanho / 2;
		} else {
			tamanho = (tamanho / 2) + 1;
		}
		int inicio = 0;
		
		for (int y = inicio; y < tamanho; y++) {

			int caso = y + 1;
			String idPedido = lista.pega(y);
			
			System.out.println(" "); //Espacamento
			System.out.println("    - Caso de Teste: " + caso + ".");
			
			baseURI = acesso.AcessoPagamento + "/" + idPedido + "/capture";
			System.out.println("      " + baseURI);
			
			String result = 
					given()
					 	.contentType("application/json")
						.header("Authorization","Basic " + acesso.CodeHash)
					.when()
						.body("")
						.post("/")
					.then()
						.assertThat()
						.statusCode(200)
						.body("id", containsString(idPedido))
						.body("status", containsString("AUTHORIZED"))
					.extract()
						.path("status");

			System.out.println("      Pagamento Capturado com sucesso!!");
			System.out.println("      Status: " + result);

		}

		System.out.println(" "); //Espacamento
		System.out.println("- SCRIPT 'CapturarPagamento': Inicio");
		
	}
}
