package Moip;

import org.junit.Test;

import static com.jayway.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class IncluirCliente {

	@Test
	public void IncluirClienteMain() {
		System.out.println("- SCRIPT 'IncluirCliente': Inicio");
		
		MassaCliente massa = new MassaCliente();
		Acesso acesso = new Acesso();
		// "https://sandbox.moip.com.br/v2/customers"
		baseURI = acesso.AcessoCliente;
		
		for (int y = 0; y < massa.retornaTamanho(); y++) {
			
			// Incluindo as informacoes do Cliente
			InclusaoCliente(y, acesso, massa);
			
		}

		System.out.println(" "); //Espacamento
		System.out.println("- SCRIPT 'IncluirCliente': Fim");
	}
	
	private void InclusaoCliente(int valor, Acesso acesso1, MassaCliente massaEntrada) {
		
		//System.out.println("  - MODULO 'InclusaoCliente': Inicio");
		System.out.println(" "); //Espacamento
		
		int caso = valor + 1;
		System.out.println("    - Caso de Teste: " + caso + ".");
		System.out.println("    " + massaEntrada.informacoes[valor]);
		
		Cliente clienteAux = new Cliente();
		
		clienteAux = massaEntrada.retornaCliente(valor);
		
		String result = 
					given()
						.contentType("application/json")
						.header("Authorization", "Basic " + acesso1.CodeHash)
					.when()
						.body(massaEntrada.informacoes[valor])
						.post("/")
					.then()
						.assertThat()
						.statusCode(201)
						.body("ownId", containsString(clienteAux.getOwnId()))
						.extract()
						.path("id");
		
		
		System.out.println("      - Caso numero: " + caso + " Incluido com sucesso.");
		System.out.println("                 ID: " + result);
		
		//Valida inclusao
		ValidaIncluaoCliente(caso, acesso1, clienteAux, result);
		
		//System.out.println("  - MODULO 'InclusaoCliente': Fim");
		
	}

	private void ValidaIncluaoCliente(int valor, Acesso acesso2, Cliente cliente, String result) {
		
		//System.out.println("    - MODULO 'ValidaIncluaoCliente': Inicio");
		//System.out.println(" "); //Espacamento entre scripts
		
			given()
				.contentType("application/json")
				.header("Authorization", "Basic " + acesso2.CodeHash)
			.when()
				.get("/" + result)
			.then()
				.assertThat()
				.statusCode(200)
				.body("ownId", containsString(cliente.getOwnId()));

		System.out.println("      - Caso numero: " + valor + " Inclusão Validada!!");
		//System.out.println(" "); //Espacamento entre scripts
		
		//System.out.println("    - MODULO 'ValidaIncluaoCliente': Fim");

	}
	
}