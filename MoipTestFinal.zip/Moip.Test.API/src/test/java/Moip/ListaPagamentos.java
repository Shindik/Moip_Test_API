package Moip;

public class ListaPagamentos {
	
	  private String[] pagamentoID = new String[100];

	  private int totalDePedidos = 0;
	  
	  public void adiciona(String pedidoId) {
		    this.pagamentoID[this.totalDePedidos] = pedidoId;
		    this.totalDePedidos++;
	  }

	  public String pega(int posicao) {
		  return this.pagamentoID[posicao];
	  }
	  
	  public int retornaTamanho() {
		  return this.totalDePedidos;
	  }
}
